SPACE TOWN GTA SA-MP Website

ไฟล์ในโปรเจกต์:
- index.html       หน้าเว็บหลัก
- style.css        ไฟล์ตกแต่งทั้งหมด
- script.js        เอฟเฟกต์ เมนูมือถือ และปุ่มคัดลอก IP
- assets/logo.png  รูปโลโก้ที่อัปโหลดมา

วิธีใช้งาน:
1. แตกไฟล์ ZIP
2. เปิด index.html ด้วย Browser
3. แก้ SERVER_IP ใน script.js เพื่อเปลี่ยน IP เซิร์ฟเวอร์
4. แก้ข้อความ/ลิงก์ Discord/Facebook/TikTok ใน index.html

จุดที่ควรแก้ก่อนใช้จริง:
- script.js บรรทัด SERVER_IP
- index.html ลิงก์ Socials ในส่วน JOIN NOW
- ชื่อเซิร์ฟเวอร์/ข้อความแนะนำตามต้องการ
